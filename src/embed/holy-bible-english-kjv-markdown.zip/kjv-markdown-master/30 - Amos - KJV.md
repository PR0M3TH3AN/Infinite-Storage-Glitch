
# Amos

## Amos Chapter 1

1 The words of Amos, who was among the herdmen of Tekoa, which he saw concerning Israel in the days of Uzziah king of Judah, and in the days of Jeroboam the son of Joash king of Israel, two years before the earthquake.

2 And he said, The Lord will roar from Zion, and utter his voice from Jerusalem; and the habitations of the shepherds shall mourn, and the top of Carmel shall wither.

3 Thus saith the Lord; For three transgressions of Damascus, and for four, I will not turn away the punishment thereof; because they have threshed Gilead with threshing instruments of iron:

4 But I will send a fire into the house of Hazael, which shall devour the palaces of Benhadad.

5 I will break also the bar of Damascus, and cut off the inhabitant from the plain of Aven, and him that holdeth the sceptre from the house of Eden: and the people of Syria shall go into captivity unto Kir, saith the Lord.

6 Thus saith the Lord; For three transgressions of Gaza, and for four, I will not turn away the punishment thereof; because they carried away captive the whole captivity, to deliver them up to Edom:

7 But I will send a fire on the wall of Gaza, which shall devour the palaces thereof:

8 And I will cut off the inhabitant from Ashdod, and him that holdeth the sceptre from Ashkelon, and I will turn mine hand against Ekron: and the remnant of the Philistines shall perish, saith the Lord God.

9 Thus saith the Lord; For three transgressions of Tyrus, and for four, I will not turn away the punishment thereof; because they delivered up the whole captivity to Edom, and remembered not the brotherly covenant:

10 But I will send a fire on the wall of Tyrus, which shall devour the palaces thereof.

11 Thus saith the Lord; For three transgressions of Edom, and for four, I will not turn away the punishment thereof; because he did pursue his brother with the sword, and did cast off all pity, and his anger did tear perpetually, and he kept his wrath for ever:

12 But I will send a fire upon Teman, which shall devour the palaces of Bozrah.

13 Thus saith the Lord; For three transgressions of the children of Ammon, and for four, I will not turn away the punishment thereof; because they have ripped up the women with child of Gilead, that they might enlarge their border:

14 But I will kindle a fire in the wall of Rabbah, and it shall devour the palaces thereof, with shouting in the day of battle, with a tempest in the day of the whirlwind:

15 And their king shall go into captivity, he and his princes together, saith the Lord.


## Amos Chapter 2

1 Thus saith the Lord; For three transgressions of Moab, and for four, I will not turn away the punishment thereof; because he burned the bones of the king of Edom into lime:

2 But I will send a fire upon Moab, and it shall devour the palaces of Kirioth: and Moab shall die with tumult, with shouting, and with the sound of the trumpet:

3 And I will cut off the judge from the midst thereof, and will slay all the princes thereof with him, saith the Lord.

4 Thus saith the Lord; For three transgressions of Judah, and for four, I will not turn away the punishment thereof; because they have despised the law of the Lord, and have not kept his commandments, and their lies caused them to err, after the which their fathers have walked:

5 But I will send a fire upon Judah, and it shall devour the palaces of Jerusalem.

6 Thus saith the Lord; For three transgressions of Israel, and for four, I will not turn away the punishment thereof; because they sold the righteous for silver, and the poor for a pair of shoes;

7 That pant after the dust of the earth on the head of the poor, and turn aside the way of the meek: and a man and his father will go in unto the same maid, to profane my holy name:

8 And they lay themselves down upon clothes laid to pledge by every altar, and they drink the wine of the condemned in the house of their god.

9 Yet destroyed I the Amorite before them, whose height was like the height of the cedars, and he was strong as the oaks; yet I destroyed his fruit from above, and his roots from beneath.

10 Also I brought you up from the land of Egypt, and led you forty years through the wilderness, to possess the land of the Amorite.

11 And I raised up of your sons for prophets, and of your young men for Nazarites. Is it not even thus, O ye children of Israel? saith the Lord.

12 But ye gave the Nazarites wine to drink; and commanded the prophets, saying, Prophesy not.

13 Behold, I am pressed under you, as a cart is pressed that is full of sheaves.

14 Therefore the flight shall perish from the swift, and the strong shall not strengthen his force, neither shall the mighty deliver himself:

15 Neither shall he stand that handleth the bow; and he that is swift of foot shall not deliver himself: neither shall he that rideth the horse deliver himself.

16 And he that is courageous among the mighty shall flee away naked in that day, saith the Lord.


## Amos Chapter 3

1 Hear this word that the Lord hath spoken against you, O children of Israel, against the whole family which I brought up from the land of Egypt, saying,

2 You only have I known of all the families of the earth: therefore I will punish you for all your iniquities.

3 Can two walk together, except they be agreed?

4 Will a lion roar in the forest, when he hath no prey? will a young lion cry out of his den, if he have taken nothing?

5 Can a bird fall in a snare upon the earth, where no gin is for him? shall one take up a snare from the earth, and have taken nothing at all?

6 Shall a trumpet be blown in the city, and the people not be afraid? shall there be evil in a city, and the Lord hath not done it?

7 Surely the Lord God will do nothing, but he revealeth his secret unto his servants the prophets.

8 The lion hath roared, who will not fear? the Lord God hath spoken, who can but prophesy?

9 Publish in the palaces at Ashdod, and in the palaces in the land of Egypt, and say, Assemble yourselves upon the mountains of Samaria, and behold the great tumults in the midst thereof, and the oppressed in the midst thereof.

10 For they know not to do right, saith the Lord, who store up violence and robbery in their palaces.

11 Therefore thus saith the Lord God; An adversary there shall be even round about the land; and he shall bring down thy strength from thee, and thy palaces shall be spoiled.

12 Thus saith the Lord; As the shepherd taketh out of the mouth of the lion two legs, or a piece of an ear; so shall the children of Israel be taken out that dwell in Samaria in the corner of a bed, and in Damascus in a couch.

13 Hear ye, and testify in the house of Jacob, saith the Lord God, the God of hosts,

14 That in the day that I shall visit the transgressions of Israel upon him I will also visit the altars of Bethel: and the horns of the altar shall be cut off, and fall to the ground.

15 And I will smite the winter house with the summer house; and the houses of ivory shall perish, and the great houses shall have an end, saith the Lord.


## Amos Chapter 4

1 Hear this word, ye kine of Bashan, that are in the mountain of Samaria, which oppress the poor, which crush the needy, which say to their masters, Bring, and let us drink.

2 The Lord God hath sworn by his holiness, that, lo, the days shall come upon you, that he will take you away with hooks, and your posterity with fishhooks.

3 And ye shall go out at the breaches, every cow at that which is before her; and ye shall cast them into the palace, saith the Lord.

4 Come to Bethel, and transgress; at Gilgal multiply transgression; and bring your sacrifices every morning, and your tithes after three years:

5 And offer a sacrifice of thanksgiving with leaven, and proclaim and publish the free offerings: for this liketh you, O ye children of Israel, saith the Lord God.

6 And I also have given you cleanness of teeth in all your cities, and want of bread in all your places: yet have ye not returned unto me, saith the Lord.

7 And also I have withholden the rain from you, when there were yet three months to the harvest: and I caused it to rain upon one city, and caused it not to rain upon another city: one piece was rained upon, and the piece whereupon it rained not withered.

8 So two or three cities wandered unto one city, to drink water; but they were not satisfied: yet have ye not returned unto me, saith the Lord.

9 I have smitten you with blasting and mildew: when your gardens and your vineyards and your fig trees and your olive trees increased, the palmerworm devoured them: yet have ye not returned unto me, saith the Lord.

10 I have sent among you the pestilence after the manner of Egypt: your young men have I slain with the sword, and have taken away your horses; and I have made the stink of your camps to come up unto your nostrils: yet have ye not returned unto me, saith the Lord.

11 I have overthrown some of you, as God overthrew Sodom and Gomorrah, and ye were as a firebrand plucked out of the burning: yet have ye not returned unto me, saith the Lord.

12 Therefore thus will I do unto thee, O Israel: and because I will do this unto thee, prepare to meet thy God, O Israel.

13 For, lo, he that formeth the mountains, and createth the wind, and declareth unto man what is his thought, that maketh the morning darkness, and treadeth upon the high places of the earth, The Lord, The God of hosts, is his name.


## Amos Chapter 5

1 Hear ye this word which I take up against you, even a lamentation, O house of Israel.

2 The virgin of Israel is fallen; she shall no more rise: she is forsaken upon her land; there is none to raise her up.

3 For thus saith the Lord God; The city that went out by a thousand shall leave an hundred, and that which went forth by an hundred shall leave ten, to the house of Israel.

4 For thus saith the Lord unto the house of Israel, Seek ye me, and ye shall live:

5 But seek not Bethel, nor enter into Gilgal, and pass not to Beersheba: for Gilgal shall surely go into captivity, and Bethel shall come to nought.

6 Seek the Lord, and ye shall live; lest he break out like fire in the house of Joseph, and devour it, and there be none to quench it in Bethel.

7 Ye who turn judgment to wormwood, and leave off righteousness in the earth,

8 Seek him that maketh the seven stars and Orion, and turneth the shadow of death into the morning, and maketh the day dark with night: that calleth for the waters of the sea, and poureth them out upon the face of the earth: The Lord is his name:

9 That strengtheneth the spoiled against the strong, so that the spoiled shall come against the fortress.

10 They hate him that rebuketh in the gate, and they abhor him that speaketh uprightly.

11 Forasmuch therefore as your treading is upon the poor, and ye take from him burdens of wheat: ye have built houses of hewn stone, but ye shall not dwell in them; ye have planted pleasant vineyards, but ye shall not drink wine of them.

12 For I know your manifold transgressions and your mighty sins: they afflict the just, they take a bribe, and they turn aside the poor in the gate from their right.

13 Therefore the prudent shall keep silence in that time; for it is an evil time.

14 Seek good, and not evil, that ye may live: and so the Lord, the God of hosts, shall be with you, as ye have spoken.

15 Hate the evil, and love the good, and establish judgment in the gate: it may be that the Lord God of hosts will be gracious unto the remnant of Joseph.

16 Therefore the Lord, the God of hosts, the Lord, saith thus; Wailing shall be in all streets; and they shall say in all the highways, Alas! alas! and they shall call the husbandman to mourning, and such as are skilful of lamentation to wailing.

17 And in all vineyards shall be wailing: for I will pass through thee, saith the Lord.

18 Woe unto you that desire the day of the Lord! to what end is it for you? the day of the Lord is darkness, and not light.

19 As if a man did flee from a lion, and a bear met him; or went into the house, and leaned his hand on the wall, and a serpent bit him.

20 Shall not the day of the Lord be darkness, and not light? even very dark, and no brightness in it?

21 I hate, I despise your feast days, and I will not smell in your solemn assemblies.

22 Though ye offer me burnt offerings and your meat offerings, I will not accept them: neither will I regard the peace offerings of your fat beasts.

23 Take thou away from me the noise of thy songs; for I will not hear the melody of thy viols.

24 But let judgment run down as waters, and righteousness as a mighty stream.

25 Have ye offered unto me sacrifices and offerings in the wilderness forty years, O house of Israel?

26 But ye have borne the tabernacle of your Moloch and Chiun your images, the star of your god, which ye made to yourselves.

27 Therefore will I cause you to go into captivity beyond Damascus, saith the Lord, whose name is The God of hosts.


## Amos Chapter 6

1 Woe to them that are at ease in Zion, and trust in the mountain of Samaria, which are named chief of the nations, to whom the house of Israel came!

2 Pass ye unto Calneh, and see; and from thence go ye to Hamath the great: then go down to Gath of the Philistines: be they better than these kingdoms? or their border greater than your border?

3 Ye that put far away the evil day, and cause the seat of violence to come near;

4 That lie upon beds of ivory, and stretch themselves upon their couches, and eat the lambs out of the flock, and the calves out of the midst of the stall;

5 That chant to the sound of the viol, and invent to themselves instruments of musick, like David;

6 That drink wine in bowls, and anoint themselves with the chief ointments: but they are not grieved for the affliction of Joseph.

7 Therefore now shall they go captive with the first that go captive, and the banquet of them that stretched themselves shall be removed.

8 The Lord God hath sworn by himself, saith the Lord the God of hosts, I abhor the excellency of Jacob, and hate his palaces: therefore will I deliver up the city with all that is therein.

9 And it shall come to pass, if there remain ten men in one house, that they shall die.

10 And a man's uncle shall take him up, and he that burneth him, to bring out the bones out of the house, and shall say unto him that is by the sides of the house, Is there yet any with thee? and he shall say, No. Then shall he say, Hold thy tongue: for we may not make mention of the name of the Lord.

11 For, behold, the Lord commandeth, and he will smite the great house with breaches, and the little house with clefts.

12 Shall horses run upon the rock? will one plow there with oxen? for ye have turned judgment into gall, and the fruit of righteousness into hemlock:

13 Ye which rejoice in a thing of nought, which say, Have we not taken to us horns by our own strength?

14 But, behold, I will raise up against you a nation, O house of Israel, saith the Lord the God of hosts; and they shall afflict you from the entering in of Hemath unto the river of the wilderness.


## Amos Chapter 7

1 Thus hath the Lord God shewed unto me; and, behold, he formed grasshoppers in the beginning of the shooting up of the latter growth; and, lo, it was the latter growth after the king's mowings.

2 And it came to pass, that when they had made an end of eating the grass of the land, then I said, O Lord God, forgive, I beseech thee: by whom shall Jacob arise? for he is small.

3 The Lord repented for this: It shall not be, saith the Lord.

4 Thus hath the Lord God shewed unto me: and, behold, the Lord God called to contend by fire, and it devoured the great deep, and did eat up a part.

5 Then said I, O Lord God, cease, I beseech thee: by whom shall Jacob arise? for he is small.

6 The Lord repented for this: This also shall not be, saith the Lord God.

7 Thus he shewed me: and, behold, the Lord stood upon a wall made by a plumbline, with a plumbline in his hand.

8 And the Lord said unto me, Amos, what seest thou? And I said, A plumbline. Then said the Lord, Behold, I will set a plumbline in the midst of my people Israel: I will not again pass by them any more:

9 And the high places of Isaac shall be desolate, and the sanctuaries of Israel shall be laid waste; and I will rise against the house of Jeroboam with the sword.

10 Then Amaziah the priest of Bethel sent to Jeroboam king of Israel, saying, Amos hath conspired against thee in the midst of the house of Israel: the land is not able to bear all his words.

11 For thus Amos saith, Jeroboam shall die by the sword, and Israel shall surely be led away captive out of their own land.

12 Also Amaziah said unto Amos, O thou seer, go, flee thee away into the land of Judah, and there eat bread, and prophesy there:

13 But prophesy not again any more at Bethel: for it is the king's chapel, and it is the king's court.

14 Then answered Amos, and said to Amaziah, I was no prophet, neither was I a prophet's son; but I was an herdman, and a gatherer of sycomore fruit:

15 And the Lord took me as I followed the flock, and the Lord said unto me, Go, prophesy unto my people Israel.

16 Now therefore hear thou the word of the Lord: Thou sayest, Prophesy not against Israel, and drop not thy word against the house of Isaac.

17 Therefore thus saith the Lord; Thy wife shall be an harlot in the city, and thy sons and thy daughters shall fall by the sword, and thy land shall be divided by line; and thou shalt die in a polluted land: and Israel shall surely go into captivity forth of his land.


## Amos Chapter 8

1 Thus hath the Lord God shewed unto me: and behold a basket of summer fruit.

2 And he said, Amos, what seest thou? And I said, A basket of summer fruit. Then said the Lord unto me, The end is come upon my people of Israel; I will not again pass by them any more.

3 And the songs of the temple shall be howlings in that day, saith the Lord God: there shall be many dead bodies in every place; they shall cast them forth with silence.

4 Hear this, O ye that swallow up the needy, even to make the poor of the land to fail,

5 Saying, When will the new moon be gone, that we may sell corn? and the sabbath, that we may set forth wheat, making the ephah small, and the shekel great, and falsifying the balances by deceit?

6 That we may buy the poor for silver, and the needy for a pair of shoes; yea, and sell the refuse of the wheat?

7 The Lord hath sworn by the excellency of Jacob, Surely I will never forget any of their works.

8 Shall not the land tremble for this, and every one mourn that dwelleth therein? and it shall rise up wholly as a flood; and it shall be cast out and drowned, as by the flood of Egypt.

9 And it shall come to pass in that day, saith the Lord God, that I will cause the sun to go down at noon, and I will darken the earth in the clear day:

10 And I will turn your feasts into mourning, and all your songs into lamentation; and I will bring up sackcloth upon all loins, and baldness upon every head; and I will make it as the mourning of an only son, and the end thereof as a bitter day.

11 Behold, the days come, saith the Lord God, that I will send a famine in the land, not a famine of bread, nor a thirst for water, but of hearing the words of the Lord:

12 And they shall wander from sea to sea, and from the north even to the east, they shall run to and fro to seek the word of the Lord, and shall not find it.

13 In that day shall the fair virgins and young men faint for thirst.

14 They that swear by the sin of Samaria, and say, Thy god, O Dan, liveth; and, The manner of Beersheba liveth; even they shall fall, and never rise up again.


## Amos Chapter 9

1 I saw the Lord standing upon the altar: and he said, Smite the lintel of the door, that the posts may shake: and cut them in the head, all of them; and I will slay the last of them with the sword: he that fleeth of them shall not flee away, and he that escapeth of them shall not be delivered.

2 Though they dig into hell, thence shall mine hand take them; though they climb up to heaven, thence will I bring them down:

3 And though they hide themselves in the top of Carmel, I will search and take them out thence; and though they be hid from my sight in the bottom of the sea, thence will I command the serpent, and he shall bite them:

4 And though they go into captivity before their enemies, thence will I command the sword, and it shall slay them: and I will set mine eyes upon them for evil, and not for good.

5 And the Lord God of hosts is he that toucheth the land, and it shall melt, and all that dwell therein shall mourn: and it shall rise up wholly like a flood; and shall be drowned, as by the flood of Egypt.

6 It is he that buildeth his stories in the heaven, and hath founded his troop in the earth; he that calleth for the waters of the sea, and poureth them out upon the face of the earth: The Lord is his name.

7 Are ye not as children of the Ethiopians unto me, O children of Israel? saith the Lord. Have not I brought up Israel out of the land of Egypt? and the Philistines from Caphtor, and the Syrians from Kir?

8 Behold, the eyes of the Lord God are upon the sinful kingdom, and I will destroy it from off the face of the earth; saving that I will not utterly destroy the house of Jacob, saith the Lord.

9 For, lo, I will command, and I will sift the house of Israel among all nations, like as corn is sifted in a sieve, yet shall not the least grain fall upon the earth.

10 All the sinners of my people shall die by the sword, which say, The evil shall not overtake nor prevent us.

11 In that day will I raise up the tabernacle of David that is fallen, and close up the breaches thereof; and I will raise up his ruins, and I will build it as in the days of old:

12 That they may possess the remnant of Edom, and of all the heathen, which are called by my name, saith the Lord that doeth this.

13 Behold, the days come, saith the Lord, that the plowman shall overtake the reaper, and the treader of grapes him that soweth seed; and the mountains shall drop sweet wine, and all the hills shall melt.

14 And I will bring again the captivity of my people of Israel, and they shall build the waste cities, and inhabit them; and they shall plant vineyards, and drink the wine thereof; they shall also make gardens, and eat the fruit of them.

15 And I will plant them upon their land, and they shall no more be pulled up out of their land which I have given them, saith the Lord thy God.


## eof
